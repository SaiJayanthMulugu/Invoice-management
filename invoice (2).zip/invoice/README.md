# Invoice Management System

A full-stack Invoice Management System built with React.js frontend and Express.js backend, using SQLite as the database.

## 🚀 Tech Stack

### Frontend
- **React.js** - UI library
- **React Router** - Navigation and routing
- **Axios** - HTTP client for API calls
- **Vite** - Build tool and development server
- **CSS3** - Styling with responsive design

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **SQLite3** - Database
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing

## ✨ Features

- ✅ User Authentication (Login/Sign Up)
- ✅ Create, Read, Update, Delete (CRUD) operations for invoices
- ✅ Invoice fields: Invoice Number, Client Name, Date, Amount, Status (Paid/Unpaid/Pending)
- ✅ Form validation
- ✅ Responsive UI design
- ✅ Sorting by Date, Amount, Client Name, Status, or Invoice Number
- ✅ Filtering by Status (Paid/Unpaid/Pending)
- ✅ User-specific invoice management (each user sees only their invoices)
- ✅ Clean and modern UI with gradient design

## 📁 Project Structure

```
invoice/
├── backend/
│   ├── server.js          # Express server and API routes
│   ├── package.json       # Backend dependencies
│   ├── .env              # Environment variables
│   └── .gitignore
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Login.jsx
│   │   │   ├── SignUp.jsx
│   │   │   ├── Home.jsx
│   │   │   └── InvoiceForm.jsx
│   │   ├── context/
│   │   │   └── AuthContext.jsx
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── package.json
│   ├── vite.config.js
│   └── index.html
└── README.md
```

## 🛠️ Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Backend Setup

1. Navigate to the backend directory:
```bash
cd invoice/backend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file (optional, defaults are set):
```env
PORT=5000
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
```

4. Start the backend server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

The backend will run on `http://localhost:5000`

### Frontend Setup

1. Navigate to the frontend directory:
```bash
cd invoice/frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The frontend will run on `http://localhost:3000`

### Build for Production

**Frontend:**
```bash
cd invoice/frontend
npm run build
```

The built files will be in the `dist` folder.

**Backend:**
The backend is ready for production. You can use process managers like PM2:
```bash
npm install -g pm2
pm2 start server.js
```

## 📡 API Endpoints

### Authentication

- `POST /api/auth/signup` - Register a new user
  - Body: `{ email, password, name }`

- `POST /api/auth/login` - Login user
  - Body: `{ email, password }`
  - Returns: `{ token, user }`

### Invoices

All invoice endpoints require authentication (Bearer token in Authorization header).

- `GET /api/invoices` - Get all invoices
  - Query params: `sortBy`, `sortOrder`, `status` (optional)
  - Returns: Array of invoices

- `GET /api/invoices/:id` - Get single invoice
  - Returns: Invoice object

- `POST /api/invoices` - Create new invoice
  - Body: `{ invoice_number, client_name, date, amount, status }`
  - Returns: Success message

- `PUT /api/invoices/:id` - Update invoice
  - Body: `{ invoice_number, client_name, date, amount, status }`
  - Returns: Success message

- `DELETE /api/invoices/:id` - Delete invoice
  - Returns: Success message

## 🗄️ Database Schema

### Users Table
- `id` (INTEGER PRIMARY KEY)
- `email` (TEXT UNIQUE NOT NULL)
- `password` (TEXT NOT NULL) - Hashed
- `name` (TEXT NOT NULL)
- `created_at` (DATETIME)

### Invoices Table
- `id` (INTEGER PRIMARY KEY)
- `invoice_number` (TEXT UNIQUE NOT NULL)
- `client_name` (TEXT NOT NULL)
- `date` (TEXT NOT NULL)
- `amount` (REAL NOT NULL)
- `status` (TEXT NOT NULL) - Paid/Unpaid/Pending
- `user_id` (INTEGER NOT NULL) - Foreign key to users
- `created_at` (DATETIME)
- `updated_at` (DATETIME)

## 🎨 Screenshots

### Login Page
- Clean login interface with email and password fields

### Sign Up Page
- Registration form with name, email, password, and confirmation

### Home Page
- Dashboard showing all invoices in a grid layout
- Filter and sort options
- Status badges with color coding
- Quick actions (Edit/Delete) for each invoice

### Invoice Form
- Create/Edit invoice form with validation
- All required fields with error messages

## 🚀 Deployment

### Frontend (Vercel/Netlify)

1. Build the frontend:
```bash
cd invoice/frontend
npm run build
```

2. Deploy the `dist` folder to Vercel or Netlify

3. Update API base URL in production (if needed)

### Backend (Render/Heroku)

1. Create a new service on Render or Heroku
2. Connect your GitHub repository
3. Set environment variables:
   - `PORT` (usually auto-set)
   - `JWT_SECRET` (generate a secure random string)
4. Deploy

**Note:** For SQLite on cloud platforms, consider using PostgreSQL or another cloud database service for production.

## 🔒 Security Notes

- Passwords are hashed using bcrypt
- JWT tokens are used for authentication
- User-specific data isolation (users can only access their own invoices)
- Input validation on both frontend and backend
- SQL injection protection through parameterized queries

## 📝 License

This project is open source and available for educational purposes.

## 👤 Author

Invoice Management System - Full Stack Application

---

**Note:** Make sure both backend and frontend servers are running for the application to work properly. The frontend is configured to proxy API requests to `http://localhost:5000` during development.

