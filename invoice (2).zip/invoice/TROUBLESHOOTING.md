# Troubleshooting Guide

## Common Issues and Solutions

### Backend Server Not Starting

**Issue:** `Error: Cannot find module 'express'`
**Solution:** Run `npm install` in the `backend` folder

**Issue:** Port 5000 already in use
**Solution:** 
- Change PORT in `.env` file, OR
- Kill the process using port 5000:
  ```powershell
  netstat -ano | findstr :5000
  taskkill /PID <PID> /F
  ```

### Frontend Server Not Starting

**Issue:** `Error: Cannot find module 'react'`
**Solution:** Run `npm install` in the `frontend` folder

**Issue:** Port 3000 already in use
**Solution:** Change port in `vite.config.js`:
```js
server: {
  port: 3001, // Change to available port
}
```

### Database Issues

**Issue:** Database locked or corrupted
**Solution:** 
- Stop the server
- Delete `backend/database.sqlite`
- Restart server (database will be recreated)

**Issue:** Tables not created
**Solution:** Check server console for errors. Tables are created automatically on first run.

### Authentication Issues

**Issue:** "Access token required" errors
**Solution:** 
- Make sure you're logged in
- Check browser console for token storage
- Try logging out and logging back in

**Issue:** Login fails silently
**Solution:** 
- Check backend server is running on port 5000
- Check browser console for CORS errors
- Verify API proxy is configured in `vite.config.js`

### CORS Errors

**Issue:** CORS policy errors in browser console
**Solution:** 
- Verify backend has `cors()` middleware enabled
- Check backend is running on correct port
- Verify frontend proxy configuration

### API Connection Issues

**Issue:** "Network Error" or "Failed to fetch"
**Solution:**
- Verify backend server is running: `http://localhost:5000`
- Check backend console for errors
- Verify frontend proxy in `vite.config.js` points to correct backend URL

### React Hooks Warnings

**Issue:** useEffect dependency warnings
**Solution:** Already fixed in code using `useCallback` hooks

## Verification Steps

1. **Check Backend:**
   ```powershell
   cd invoice/backend
   npm start
   ```
   Should see: "Server running on port 5000"

2. **Check Frontend:**
   ```powershell
   cd invoice/frontend
   npm run dev
   ```
   Should see: "Local: http://localhost:3000"

3. **Test API:**
   Open browser to `http://localhost:3000`
   - Should see login page
   - Create account
   - Login
   - Create invoice

## Development Tips

- Always start backend before frontend
- Check browser console (F12) for frontend errors
- Check terminal/console for backend errors
- Use browser DevTools Network tab to debug API calls
- Clear browser localStorage if authentication issues persist

