# Quick Setup Guide

## Quick Start (Development)

### Terminal 1 - Backend
```bash
cd invoice/backend
npm install
npm start
```

### Terminal 2 - Frontend
```bash
cd invoice/frontend
npm install
npm run dev
```

Then open `http://localhost:3000` in your browser.

## First Time Setup

1. **Install Node.js** (if not already installed)
   - Download from https://nodejs.org/
   - Verify: `node --version`

2. **Backend Setup**
   ```bash
   cd invoice/backend
   npm install
   ```
   - The database will be created automatically on first run
   - Default port: 5000

3. **Frontend Setup**
   ```bash
   cd invoice/frontend
   npm install
   ```
   - Default port: 3000
   - API proxy configured to backend

4. **Start Both Servers**
   - Backend: `npm start` (in backend folder)
   - Frontend: `npm run dev` (in frontend folder)

## Testing the Application

1. Open `http://localhost:3000`
2. Click "Sign up" to create a new account
3. Login with your credentials
4. Create your first invoice!

## Troubleshooting

**Port already in use:**
- Backend: Change PORT in `.env` file
- Frontend: Change port in `vite.config.js`

**Database errors:**
- Delete `database.sqlite` and restart the server
- The database will be recreated automatically

**CORS errors:**
- Make sure backend is running on port 5000
- Check that frontend proxy is configured correctly

**Module not found:**
- Run `npm install` in both backend and frontend folders
- Delete `node_modules` and reinstall if issues persist

