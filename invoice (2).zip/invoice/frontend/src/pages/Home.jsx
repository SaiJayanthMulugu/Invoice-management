import { useState, useEffect, useCallback } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import axios from 'axios'
import './Home.css'

function Home() {
  const [invoices, setInvoices] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [sortBy, setSortBy] = useState('date')
  const [sortOrder, setSortOrder] = useState('desc')
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const fetchInvoices = useCallback(async () => {
    try {
      setLoading(true)
      const params = { sortBy, sortOrder }
      if (filterStatus) params.status = filterStatus
      
      const response = await axios.get('/api/invoices', { params })
      setInvoices(response.data)
      setError('')
    } catch (error) {
      setError('Failed to fetch invoices')
      console.error('Error fetching invoices:', error)
    } finally {
      setLoading(false)
    }
  }, [filterStatus, sortBy, sortOrder])

  useEffect(() => {
    fetchInvoices()
  }, [fetchInvoices])

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this invoice?')) {
      return
    }

    try {
      await axios.delete(`/api/invoices/${id}`)
      fetchInvoices()
    } catch (error) {
      alert('Failed to delete invoice')
      console.error('Error deleting invoice:', error)
    }
  }

  const getStatusClass = (status) => {
    switch (status) {
      case 'Paid':
        return 'status-paid'
      case 'Unpaid':
        return 'status-unpaid'
      case 'Pending':
        return 'status-pending'
      default:
        return ''
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  return (
    <div className="home-container">
      <header className="home-header">
        <div className="header-content">
          <h1>Invoice Management System</h1>
          <div className="header-actions">
            <span className="user-name">Welcome, {user?.name}</span>
            <button onClick={logout} className="btn btn-secondary">
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="container">
        <div className="home-actions">
          <Link to="/invoice/new" className="btn btn-primary">
            + Create New Invoice
          </Link>
        </div>

        <div className="filters-section">
          <div className="filter-group">
            <label htmlFor="filterStatus">Filter by Status:</label>
            <select
              id="filterStatus"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <option value="">All</option>
              <option value="Paid">Paid</option>
              <option value="Unpaid">Unpaid</option>
              <option value="Pending">Pending</option>
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="sortBy">Sort by:</label>
            <select
              id="sortBy"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="date">Date</option>
              <option value="amount">Amount</option>
              <option value="client_name">Client Name</option>
              <option value="status">Status</option>
              <option value="invoice_number">Invoice Number</option>
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="sortOrder">Order:</label>
            <select
              id="sortOrder"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            >
              <option value="desc">Descending</option>
              <option value="asc">Ascending</option>
            </select>
          </div>
        </div>

        {error && <div className="error-message">{error}</div>}

        {loading ? (
          <div className="loading">Loading invoices...</div>
        ) : invoices.length === 0 ? (
          <div className="empty-state">
            <p>No invoices found. Create your first invoice!</p>
          </div>
        ) : (
          <div className="invoices-grid">
            {invoices.map((invoice) => (
              <div key={invoice.id} className="invoice-card">
                <div className="invoice-header">
                  <h3>{invoice.invoice_number}</h3>
                  <span className={`status-badge ${getStatusClass(invoice.status)}`}>
                    {invoice.status}
                  </span>
                </div>
                <div className="invoice-details">
                  <p><strong>Client:</strong> {invoice.client_name}</p>
                  <p><strong>Date:</strong> {formatDate(invoice.date)}</p>
                  <p><strong>Amount:</strong> {formatAmount(invoice.amount)}</p>
                </div>
                <div className="invoice-actions">
                  <button
                    onClick={() => navigate(`/invoice/edit/${invoice.id}`)}
                    className="btn btn-secondary"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(invoice.id)}
                    className="btn btn-danger"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default Home

