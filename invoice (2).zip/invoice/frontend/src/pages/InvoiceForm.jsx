import { useState, useEffect, useCallback } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios'
import './InvoiceForm.css'

function InvoiceForm() {
  const { id } = useParams()
  const isEdit = !!id
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    invoice_number: '',
    client_name: '',
    date: '',
    amount: '',
    status: 'Pending'
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [fetching, setFetching] = useState(isEdit)

  const fetchInvoice = useCallback(async () => {
    try {
      setFetching(true)
      const response = await axios.get(`/api/invoices/${id}`)
      const invoice = response.data
      setFormData({
        invoice_number: invoice.invoice_number,
        client_name: invoice.client_name,
        date: invoice.date,
        amount: invoice.amount.toString(),
        status: invoice.status
      })
    } catch (error) {
      alert('Failed to fetch invoice')
      navigate('/')
    } finally {
      setFetching(false)
    }
  }, [id, navigate])

  useEffect(() => {
    if (isEdit) {
      fetchInvoice()
    }
  }, [isEdit, fetchInvoice])

  const validate = () => {
    const newErrors = {}

    if (!formData.invoice_number.trim()) {
      newErrors.invoice_number = 'Invoice number is required'
    }

    if (!formData.client_name.trim()) {
      newErrors.client_name = 'Client name is required'
    }

    if (!formData.date) {
      newErrors.date = 'Date is required'
    }

    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Valid amount is required'
    }

    if (!formData.status) {
      newErrors.status = 'Status is required'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validate()) {
      return
    }

    setLoading(true)

    try {
      const payload = {
        ...formData,
        amount: parseFloat(formData.amount)
      }

      if (isEdit) {
        await axios.put(`/api/invoices/${id}`, payload)
      } else {
        await axios.post('/api/invoices', payload)
      }

      navigate('/')
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Failed to save invoice'
      alert(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  if (fetching) {
    return (
      <div className="form-container">
        <div className="loading">Loading invoice...</div>
      </div>
    )
  }

  return (
    <div className="form-container">
      <div className="form-card">
        <div className="form-header">
          <h1>{isEdit ? 'Edit Invoice' : 'Create New Invoice'}</h1>
          <button onClick={() => navigate('/')} className="btn btn-secondary">
            Cancel
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="invoice_number">Invoice Number *</label>
            <input
              type="text"
              id="invoice_number"
              name="invoice_number"
              value={formData.invoice_number}
              onChange={handleChange}
              required
            />
            {errors.invoice_number && (
              <div className="error-message">{errors.invoice_number}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="client_name">Client Name *</label>
            <input
              type="text"
              id="client_name"
              name="client_name"
              value={formData.client_name}
              onChange={handleChange}
              required
            />
            {errors.client_name && (
              <div className="error-message">{errors.client_name}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="date">Date *</label>
            <input
              type="date"
              id="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
            />
            {errors.date && (
              <div className="error-message">{errors.date}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="amount">Amount *</label>
            <input
              type="number"
              id="amount"
              name="amount"
              value={formData.amount}
              onChange={handleChange}
              step="0.01"
              min="0"
              required
            />
            {errors.amount && (
              <div className="error-message">{errors.amount}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="status">Status *</label>
            <select
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
              required
            >
              <option value="Pending">Pending</option>
              <option value="Paid">Paid</option>
              <option value="Unpaid">Unpaid</option>
            </select>
            {errors.status && (
              <div className="error-message">{errors.status}</div>
            )}
          </div>

          <div className="form-actions">
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : isEdit ? 'Update Invoice' : 'Create Invoice'}
            </button>
            <button
              type="button"
              onClick={() => navigate('/')}
              className="btn btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default InvoiceForm

